@file:OptIn(InternalResourceApi::class)

package ee.schimke.wearcmp.material3.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem

private const val MD: String = "composeResources/ee.schimke.wearcmp.material3.resources/"

@delegate:ResourceContentHash(-895_536_595)
public val Res.drawable.wear_m3c_check_animation: DrawableResource by lazy {
      DrawableResource("drawable:wear_m3c_check_animation", setOf(
        ResourceItem(setOf(), "${MD}drawable/wear_m3c_check_animation.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_545_603_043)
public val Res.drawable.wear_m3c_error: DrawableResource by lazy {
      DrawableResource("drawable:wear_m3c_error", setOf(
        ResourceItem(setOf(), "${MD}drawable/wear_m3c_error.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_220_494_492)
public val Res.drawable.wear_m3c_failure_animation: DrawableResource by lazy {
      DrawableResource("drawable:wear_m3c_failure_animation", setOf(
        ResourceItem(setOf(), "${MD}drawable/wear_m3c_failure_animation.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_293_908_545)
public val Res.drawable.wear_m3c_open_on_phone_animation: DrawableResource by lazy {
      DrawableResource("drawable:wear_m3c_open_on_phone_animation", setOf(
        ResourceItem(setOf(), "${MD}drawable/wear_m3c_open_on_phone_animation.xml", -1, -1),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainDrawable0Resources(map: MutableMap<String, DrawableResource>) {
  map.put("wear_m3c_check_animation", Res.drawable.wear_m3c_check_animation)
  map.put("wear_m3c_error", Res.drawable.wear_m3c_error)
  map.put("wear_m3c_failure_animation", Res.drawable.wear_m3c_failure_animation)
  map.put("wear_m3c_open_on_phone_animation", Res.drawable.wear_m3c_open_on_phone_animation)
}
